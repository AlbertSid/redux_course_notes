# Andriod 开发的环境配置（win）

1. Andriod Studio 
2. Java
3. SDK
4. NDK 

一、环境变量配置
JAVA_HOME : c:/XXX/java/jdk.....
ANDRIOD_HOME : sdk对应的目录
ANDRIOD_NDK_HOME : dnk对应的目录
GRADLE_HOME : Andriod Studio 软件目录下/gradle/gradle-5
CLASSPATH: %JAVA_HOME%\lib\dt.jar;%JAVA_HOME%\lib\tools.jar

Path: %JAVA_HOME%\bin;%ANDRIOD_HOME%\platform-tools;%GRADLE_HOME%\bin

二、对应的打开Andriod Studio可以手动设置。SDK,DNK, gradle 路径