#win服务器配置

需要相关软件
一.Apache

1.httpd.conf 下
假如：Apache的目录 = D:/Apache
ServerRoot: D:/Apache
DocumentRoot: D:/Apache/htdocs
...
找到所有的Apache替换成Apache的目录


PHPIniDir : 配置成PHP的目录
...

2.httpd-vhosts.conf 下

配置PHP服务端代码的地址：并映射到对应的——自己的网址下。
比如：服务端的代码在 D：www/phpserver下
'''
<Vir.... *:80>
	DocumentRoot 'D：www/phpserver'
	ServerName www.test.com
	....
</Vir>
'''



二。PHP

1. php.ini文件下
配置：
extension_dir = "d:/PHP7/ext"
zend_extension = "d:/PHP7/...."

2.全局环境变量的Path配置，PHP5目录

三. Host
配置IP与域名网址的映射